export class Account {
    id: string;
    account_name: string;
    logo: string;
    trading_name: string;
    group_code: string;
    site_code: string;
    site_name: string;
    company: string;
    site_type: string;
    emergency_phone_number: string;
    main_contact_id: string;
    active: boolean;
    url: string;
    created_by: string;
    created_at: string;
    updated_by: string;
    updated_at: string;
    is_admin: boolean;
    is_dev_account: boolean;
    is_supplier: boolean;
    use_asn: boolean;
    account_type: string;
    vlm_length: number;
}
