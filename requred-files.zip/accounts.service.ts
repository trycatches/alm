import { RegisterUser } from 'src/app/models/register-user';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { environment } from 'src/environments/environment';
import { AccountCheck } from '../models/account-check';
import { Location } from '../models/location';
import { Register } from '../models/register';
import { User } from '../models/user';
import { Observable, Subject, BehaviorSubject, of } from 'rxjs';
import { Account } from '../models/account';
import { Partner } from '../models/partner';
import { TracesAccountInvite } from '../models/traces-account-invite';
import { Supplier } from '../models/supplier';
import { Plan } from '../models/plan';
import { TracesInvite } from '../models/traces-invite';

const API_URL = environment.apiUrl;

@Injectable({
  providedIn: 'root'
})
export class AccountsService {
  private account = new Subject<Account>();
  public falseToTrue = new BehaviorSubject<any>('');
  currentAccount: Observable<Account> = this.account;
  constructor(private http: HttpClient) { }

  setRoute(valueChange: any) {
    this.falseToTrue.next(valueChange);
  }

  getRoute() {
    return this.falseToTrue.asObservable();
  }

  checkAccount(accountname: string) {
    return this.http.get<AccountCheck>(API_URL + '/v1/accounts/account/check/' + accountname);
  }
  

  getCurrentAccount(): Observable<Account> {
    return this.http.get<Account>(API_URL + '/v1/accounts/account');
  }

  getCurrentAuth0Account(): Observable<Account> {
    return this.http.get<Account>(API_URL + '/v1/accounts/account');
  }

  getSupplyChainsdata(accountID,Groupcode){ //**for account info page */
    return this.http.get<any>(API_URL + `/v1/accounts/account/${Groupcode}/${accountID}/supplychainsuppliercodes`);
    
  }

  getAllPermissions(){
    return this.http.get<any>(API_URL + `/v1/accounts/oauth/permissions`);
  }

  setAccount(){
    this.http.get<Account>(API_URL + '/v1/accounts/account').subscribe((res: Account) => {
      this.account.next(res);
    });
  }

  saveAccount(account: any) {
    return this.http.put(API_URL + '/v1/accounts/account', account);
  }
  goToPayment(count: any): Observable<any> {
    return this.http.post(`${API_URL}/accounts/billing/gc/initiate_direct_debit_flow`, count);
  }

  PaymentSuccess(count: any): Observable<any> {
    return this.http.post(`${API_URL}/accounts/billing/gc/complete_direct_debit_flow`, count);
  }

  PaymentViaSaveData(count: any) {
    return this.http.post(`${API_URL}/accounts/billing/gc/subscribe`, count);
  }

  getAllUsers() {
    return this.http.get<any>(`${API_URL}/v1/accounts/user`);
    // return this.http.get(API_URL + '/users');
  }

  getCurrentUser() {
    return this.http.get<any>(`${API_URL}/v1/accounts/user/me`);
  }

  getUserById(id: string) {
    return this.http.get(`${API_URL}/v1/accounts/user/${id}`);
  }

  saveUser(user: any) {
    return this.http.put(`${API_URL}/v1/accounts/user/${user.id}`,user);
  }
  // }
  deleteUser(id:string) {
    return this.http.delete(`${API_URL}/v1/accounts/user/${id}`);
  }
  
  getLocations(): Observable<Location[]> {
    //return this.http.get<Location[]>(API_URL + '/locations');
    return this.http.get<Location[]>(API_URL + '/v1/accounts/location');
  }
  getLocationsByGroup(): Observable<Location[]> {
    return this.http.get<Location[]>(API_URL + '/locations/name/by/group');
  }

  getLocationsByGroupBySupplyChain(supplyChainId: string): Observable<Location[]> {
    return this.http.get<Location[]>(API_URL + `/v1/accounts/location/locationlistbysupplychainid?supplyChainId=${supplyChainId}`);
  }

  getSupplyChainByGroupCode(groupCode):Observable<any> {
    return this.http.get<any>(`${API_URL}/v1/accounts/accountinvite/supplychainbygroupcode?groupcode=${groupCode}`);
  }

  getDestinationsByGroup(): Observable<Location[]> {
    return this.http.get<Location[]>(API_URL + '/v1/accounts/location/name/from/directories');
  }

  getLocationById(id: string): Observable<Location> {
    return this.http.get<Location>(API_URL + '/v1/accounts/location/id?id=' + id);
  }

  getLocationByAccountId(accountId: string): Observable<Location> {
    return this.http.get<Location>(API_URL + '/v1/accounts/location/get_by_account/' + accountId);
  }


  deleteLocation(id: string) {
    return this.http.delete(API_URL + '/v1/accounts/location/deletebyid?id=' + id);
  }

  saveLocation(location: Location) {
    return this.http.put(API_URL + '/v1/accounts/location', location);
  }

  createLocation(location: Location) {
    return this.http.post(API_URL + '/v1/accounts/location', location);
  }

  sendEmailInvite(email: string) {
    return this.http.post(`${API_URL}/v1/accounts/userinvite`, { 'email': email });
  }

  registerNewAccount(registerRequest: Register): Observable<any> {
    return this.http.post(`${API_URL}/v1/accounts/accountinvite/signup`, registerRequest);
  }

  sendDeviceMessage(userId: string, msgTitle: string, msgBody: string) {
    return this.http.post(`${API_URL}/users/${userId}/device_message`, { title: msgTitle, message: msgBody });
  }
  copyTemplate(account_id: any): Observable<any[]> {
    return this.http.post<any>(`${API_URL}/v3/traces/copytemplate/${account_id}`, "");
  }

  getEmailInvite(token: string) {
      return this.http.get(`${API_URL}/v1/accounts/userinvite/getinviteinfo/${token}`);
  }

  signupFromEmailInvite(token: string, user: User) {
    return this.http.post(`${API_URL}/services/accounts/user_invite/${token}`, user);
  }

  registerUserFromEmailLink(migrateUser: RegisterUser) {
    return this.http.post(`${API_URL}/v1/accounts/user/registerfrominvite`, migrateUser);
  }

  linkUserFromEmailLink(token,accountId,email,password) {
    let user={ 
      account_id: accountId,
      email:email,
      password:password,
      token:token
    }
    return this.http.post(`${API_URL}/v1/accounts/user/map/invitedauth0user`, user);
  }

  getSuppliers(): Observable<Supplier[]> {
    return this.http.get<Supplier[]>(API_URL + '/account/suppliers');
  }

  getSupplierById(id: string): Observable<Supplier> {
    return this.http.get<Supplier>(API_URL + '/account/suppliers/' + id);
  }

  saveSupplier(supplier: Supplier) {
    return this.http.put(API_URL + '/account/suppliers/' + supplier.id, supplier);
  }

  createSupplier(supplier: Supplier) {
    return this.http.put(API_URL + '/account/suppliers', supplier);
  }

  getPartners(): Observable<Partner[]> {
    return this.http.get<Partner[]>(API_URL + '/account/partners');
  }

  getPartnerById(id: string): Observable<Partner> {
    return this.http.get<Partner>(API_URL + '/account/partners/' + id);
  }

  savePartner(partner: Partner) {
    return this.http.put(API_URL + '/account/partners/' + partner.id, partner);
  }

  createPartner(partner: Partner) {
    return this.http.put(API_URL + '/account/partners', partner);
  }

  sendTracesInviteEmail(inviteRequest: TracesAccountInvite) {
    return this.http.post(`${API_URL}/services/accounts/traces/invite_email`, inviteRequest);
  }

  getPlans(): Observable<Plan[]> {
    return this.http.get<Plan[]>(API_URL + '/plan');
  }

  getTracesInvite(token: string) {
    return this.http.get<TracesInvite>(`${API_URL}/services/accounts/traces_invite/${token}`);
  }
  getUserInvite(token: string) {
    return this.http.get(`${API_URL}/v1/accounts/accountinvite/getinviteinfo?token=${token}`);
  }

  getSupplyChainDetails (GroupCode: any) { /**for register page */
    return this.http.get(`${API_URL}/v1/accounts/accountinvite/supplychainbygroupcode?groupcode=${GroupCode}&api-version=v1`);
  }
  
  getTracesType(token: string) {
    return this.http.get(`${API_URL}/v1/accounts/accountinvite/getinviteinfo?token=${token}`);
  }

  getCurrentReleaseNote(): Observable<any> {
    return this.http.get(`${API_URL}/v1/accounts/account/release_notes/current`);
  }

  getUserAuth0Accounts():Observable<any> {
    return this.http.get<any>(`${API_URL}/v1/accounts/user/getaccounts`);
  }

  getNotificationData():Observable<any>{
    return this.http.get<any>(`${API_URL}/v1/sps/notificationcounter`);
  }

  getCurrentRole(userId : string, accountId:string): Observable<any> {
    return this.http.get<Account>(API_URL + `/v1/accounts/user/userrole/${userId}/${accountId}`);
  }
}
